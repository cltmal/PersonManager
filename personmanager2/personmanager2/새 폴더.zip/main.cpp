#include <iostream>

#include "PersonView.h"
#include "PersonLoop.h"
using namespace std;

void main()
{
	PersonLoop loop;
	loop.RunLoop();
}